package sk.stuba.fiit.kvasnicka.qsimsimulation.helpers;

import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.Edge;
import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.NetworkNode;

/**
 * here all fixed delays are calculated
 *
 * @author Igor Kvasnicka
 */
public abstract class DelayHelper {

    public static final int MIN_PROCESSING_DELAY = 5; //msec

    //todo overit, ci vsetky tieto metody davaju vysledok v msec a nie v sec

    public static double calculateSerialisationDelay(Edge edge, int packetSize) {
        if (edge == null) throw new IllegalArgumentException("edge is NULL");
        return (double) packetSize / edge.getSpeed();
    }

    public static double calculatePropagationDelay(Edge edge) {
        if (edge == null) throw new IllegalArgumentException("edge is NULL");
        return edge.getLength() / (2.1 * Math.pow(10, 8));
    }

    public static double calculateProcessingDelay(NetworkNode networkNode) {
        return 10D;
    }

    /**
     * calculates serialisation delay between two given nodes (specified by the edge between them)
     *
     * @param edge       edge edge between two nodes; edge that packet is being send by
     * @param packetSize size of the packet to be serialised
     * @return time to serialise
     */
    public double getSerialisationDelay(Edge edge, int packetSize) {//todo serialisation dely is never called
        if (edge == null) throw new IllegalArgumentException("edge is NULL");
        return packetSize / (double) edge.getSpeed();
    }
}
