package sk.stuba.fiit.kvasnicka.qsimdatamodel.data;

/**
 * @author Igor Kvasnicka
 */
public class ComputerVertex extends TopologyVertex {
    Computer c;
    public ComputerVertex() {
    }
}
