package sk.stuba.fiit.kvasnicka.qsimdatamodel.data;

/**
 * @author Igor Kvasnicka
 */
public abstract class TopologyVertex  {
    public TopologyVertex() {
    }
}
