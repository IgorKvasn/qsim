/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stuba.fiit.kvasnicka.qsimsimulation.enums;

/**
 * @author Igor Kvasnicka
 */
public enum PacketTypeEnum {
    AUDIO_PACKET,
    VIDEO_PACKET,
    DATA_PACKET,
    CUSTOM
}
