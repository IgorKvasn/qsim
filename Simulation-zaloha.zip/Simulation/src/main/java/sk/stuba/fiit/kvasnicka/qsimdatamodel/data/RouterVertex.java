package sk.stuba.fiit.kvasnicka.qsimdatamodel.data;

/**
 * @author Igor Kvasnicka
 */
public class RouterVertex extends TopologyVertex{
    Router router;
    public RouterVertex() {
    }
}
