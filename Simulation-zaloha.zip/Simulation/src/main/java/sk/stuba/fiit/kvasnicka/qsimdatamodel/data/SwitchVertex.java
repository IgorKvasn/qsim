package sk.stuba.fiit.kvasnicka.qsimdatamodel.data;

/**
 * @author Igor Kvasnicka
 */
public class SwitchVertex extends TopologyVertex{
    Switch s;
    public SwitchVertex() {
    }
}
