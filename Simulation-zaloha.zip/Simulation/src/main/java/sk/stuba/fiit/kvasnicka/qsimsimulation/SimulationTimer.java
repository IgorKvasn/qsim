package sk.stuba.fiit.kvasnicka.qsimsimulation;

import lombok.Getter;
import org.apache.log4j.Logger;
import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.Edge;
import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.NetworkNode;
import sk.stuba.fiit.kvasnicka.qsimsimulation.helpers.DelayHelper;
import sk.stuba.fiit.kvasnicka.qsimsimulation.managers.PacketManager;
import sk.stuba.fiit.kvasnicka.qsimsimulation.managers.SimulationManager;
import sk.stuba.fiit.kvasnicka.qsimsimulation.managers.TopologyManager;
import sk.stuba.fiit.kvasnicka.qsimsimulation.packet.Packet;

import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Simulation timer that awakes and do all the simulation stuff.
 * Simple javax.swing.Timer is used.
 * what does timer do? (order is important)
 * 1. generates new packets for all simulation rules
 * 2. checks all network nodes and processes all packets that are in "on the wire" state
 * 3. changes network node statistics
 *
 * @author Igor Kvasnicka
 */
public class SimulationTimer implements ActionListener {
    private Logger logg = Logger.getLogger(SimulationTimer.class);
    public static final int TIME_QUANTUM = DelayHelper.MIN_PROCESSING_DELAY + 1; //or also known as "timer delay" :)
    private Timer timer;
    @Getter
    private PacketGenerator packetGenerator;
    @Getter
    private double simulationTime;
    private SimulationManager simulationManager;
    @Getter
    private PacketManager packetManager;
    @Getter
    private TopologyManager topologyManager;

    public SimulationTimer(List<Edge> edgeList, List<NetworkNode> nodeList) {
        topologyManager = new TopologyManager(edgeList, nodeList);
    }

    /**
     * starts the timer
     *
     * @param simulationManager reference to SimulationManager object
     */
    public void startSimulationTimer(SimulationManager simulationManager) {
        packetManager = new PacketManager(this);
        this.simulationManager = simulationManager;
        packetGenerator = new PacketGenerator(simulationManager.getRulesUnmodifiable(), this, topologyManager.getEdgeList(), topologyManager.getNodeList());

        for (NetworkNode node : getTopologyManager().getNodeList()) {
            node.setTopologyManager(topologyManager);
        }

        timer = new Timer(TIME_QUANTUM, this);
        logg.debug("starting simulation timer");
        timer.start();
    }


    /**
     * cancels simulation timer
     *
     * @see #clearSimulationData()
     */
    public void stopTimer() {
        if (timer == null) throw new IllegalStateException("timer is NULL");
        logg.debug("stopping simulation timer");
        timer.stop();
    }

    /**
     * clears all data left after the simulation process
     * use this method only when timer is stopped
     */
    public void clearSimulationData() {
        if (timer == null) throw new IllegalStateException("timer is NULL");
        if (timer.isRunning()) {
            throw new IllegalStateException("cannot clear simulation data - simulation timer is running");
        }
        packetManager.clearAllPackets();
    }

    /**
     * this method is called when timer awakes
     *
     * @param event
     */
    public void actionPerformed(ActionEvent event) {
        try {

            simulationTime += TIME_QUANTUM;//increase simulation clock


            //--------handle all packets in PROCESSING state and see what can I do about them i.e. change THEIR status first
            //here is QoS used (RED/WRED,...) to put packets into output queue
            packetManager.moveProcessedPackets(simulationTime);

            //-------generate new packets in all network nodes
            //new packets are created into output buffer, so generatePavkets() should be called before emptying output buffers
            packetGenerator.generatePackets(simulationTime, TIME_QUANTUM);

            //todo the rest of the timer tick method can be paralelized


            //-------- empty output queues - move apply QoS and move packets to OUTPUT_SERIALISATION state
            packetManager.movePacketsFromOutputQueue(simulationTime);


            //--------change status of all packets
            List<Packet> packetsToChange = packetManager.getAllPacketsOnTheWire(simulationTime);//here are all packets that are waiting to change their state
            packetManager.changePacketsState(packetsToChange, simulationTime);//change their state


            //---------now calculate statistic data
            //todo vypocitaj vyuzitie output queues - vysledok hod do QueueDefinition.usedCapacity
        } catch (Throwable throwable) {
            //just to make it fail-safe catch all possible problems
            logg.error("Error during timer execution", throwable);
        }
    }

    /**
     * sets delay of the timer
     * this method is called from GUI when user decides to speed up/slow down simulation
     *
     * @param speedUp no float or double speed up allowed; also no negative or less then 1
     */
    public void setTimerDelay(int speedUp) {
        if (speedUp < 1) throw new IllegalArgumentException("speedUp must not be less then 1");
        timer.setDelay(convertTime(speedUp));
    }

    private int convertTime(int speedUp) {
        return TIME_QUANTUM * speedUp;
    }
}
