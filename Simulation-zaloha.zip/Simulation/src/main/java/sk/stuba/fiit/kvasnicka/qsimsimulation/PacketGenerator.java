package sk.stuba.fiit.kvasnicka.qsimsimulation;

import org.apache.log4j.Logger;
import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.Edge;
import sk.stuba.fiit.kvasnicka.qsimdatamodel.data.NetworkNode;
import sk.stuba.fiit.kvasnicka.qsimsimulation.enums.PacketTypeEnum;
import sk.stuba.fiit.kvasnicka.qsimsimulation.managers.PacketManager;
import sk.stuba.fiit.kvasnicka.qsimsimulation.packet.Packet;

import java.util.LinkedList;
import java.util.List;

/**
 * this class is used to generate packets according to simulation rules
 *
 * @author Igor Kvasnicka
 */
public class PacketGenerator {
    private static final Logger logg = Logger.getLogger(PacketGenerator.class);

    private List<SimulationRuleBean> simulationRules;
    private SimulationTimer simulationTimer;
    private PacketManager packetManager;


    public PacketGenerator(List<SimulationRuleBean> simulationRules, SimulationTimer simulationTimer, List<Edge> edgeList, List<NetworkNode> nodeList) {
        this.simulationRules = simulationRules;
        this.simulationTimer = simulationTimer;
        packetManager = simulationTimer.getPacketManager();
    }

    /**
     * creates new packets for all network nodes
     *
     * @param simulationTime current simulation time
     * @param timeQuantum    how much time do I have
     */
    public void generatePackets(double simulationTime, int timeQuantum) {    //todo co tu robi parameter timeQuantum
        //todo paralelize me - ExecutorService
        for (SimulationRuleBean rule : simulationRules) {
            if (rule.isFinished()) continue; //I don't care about finished simulation rules
            if (rule.isActive() && ! rule.isFinished()) {
                addPacketsToNetworkNode(timeQuantum, simulationTime, rule);
            } else {//check if the time came to activate this rule
                if (checkRuleActivate(rule, simulationTime)) {//yes, I should activate it
                    rule.setActive(true);
                    double time = timeQuantum - rule.getActiveDelay();//rule activation may not happen at exact timer tick, but some time later (during the same time quantum)
                    addPacketsToNetworkNode(time, simulationTime, rule);
                }
            }
            //after the rule is used I will take care of rule repetition
            rule.decreaseRuleRepetition();
        }
    }

    private void addPacketsToNetworkNode(double timeQuantum, double simulationTime, SimulationRuleBean rule) {
        List<Packet> packets = generatePacketsSimulRule(timeQuantum, rule.getPacketSize(), rule.getDestination(), rule.getSource(), rule.getPacketTypeEnum());
        packetManager.initPackets(rule.getSource(), packets, simulationTime);
    }

    /**
     * checks if not active rule should became active (initial delay has expired)
     *
     * @param rule
     * @param simulationTime
     * @return true if rule should be set to active state
     */
    private boolean checkRuleActivate(SimulationRuleBean rule, double simulationTime) {
        return simulationTime >= rule.getActiveDelay();
    }

    /**
     * creates new packets for one simulation rule
     * <p/>
     * creates as much packets as possible - each packet takes some time ("serialisationDelay")
     * to create and there is only a small amount of time ("timeQuantum") to work with
     *
     * @param timeQuantum
     * @param packetSize
     * @param destination
     * @param source
     * @param packetTypeEnum
     * @return
     */
    private List<Packet> generatePacketsSimulRule(double timeQuantum, int packetSize, NetworkNode destination, NetworkNode source, PacketTypeEnum packetTypeEnum) {
        List<Packet> packets = new LinkedList<Packet>();
        double timeToSpend = timeQuantum;
        while (timeToSpend > 0) {
            double serialisationDelay = simulationTimer.getTopologyManager().getSerialisationDelay(source, destination, packetSize);
            if (serialisationDelay > timeQuantum) break; //I have got no time left
            packets.add(createPacket(packetSize, destination, source, packetTypeEnum, simulationTimer.getSimulationTime()));
            timeToSpend -= serialisationDelay;//I have spent some time
        }
        return packets;
    }

    /**
     * creates one packet
     *
     * @param packetSize
     * @param destination
     * @param source
     * @param packetTypeEnum
     * @param creationTime
     * @return
     */
    private Packet createPacket(int packetSize, NetworkNode destination, NetworkNode source, PacketTypeEnum packetTypeEnum, double creationTime) {
        Packet packet = new Packet(packetSize, destination, source, packetManager, packetTypeEnum, creationTime);
        int mark = source.getQosMechanism().markPacket(packet); //todo mark delay
        packet.setQosQueue(mark);
        return packet;
    }
}
