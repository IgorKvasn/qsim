package sk.stuba.fiit.kvasnicka.qsimsimulation;

/**
 * @author Igor Kvasnicka
 */
public class IntegrationTest {
    public IntegrationTest() {
    }
}
